using System;
using System.Runtime.InteropServices;

// Dumps every winmm mixer device, its lines/source lines and controls (incl. MUX/selector items).
class MixerDump
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
    struct MIXERCAPS { public ushort wMid, wPid; public uint vDriverVersion; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szPname; public uint fdwSupport, cDestinations; }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
    struct MIXERLINE
    {
        public int cbStruct; public uint dwDestination, dwSource, dwLineID, fdwLine; public IntPtr dwUser; public uint dwComponentType, cChannels, cConnections, cControls;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)] public string szShortName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string szName;
        public uint dwType, dwDeviceID; public ushort wMid, wPid; public uint vDriverVersion;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szPname;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
    struct MIXERCONTROL
    {
        public int cbStruct; public uint dwControlID, dwControlType, fdwControl, cMultipleItems;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)] public string szShortName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string szName;
        public int lMinimum, lMaximum; [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)] public int[] reserved1;
        public uint cSteps; [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)] public int[] reserved2;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    struct MIXERLINECONTROLS { public int cbStruct; public uint dwLineID, dwControl, cControls; public int cbmxctrl; public IntPtr pamxctrl; }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    struct MIXERCONTROLDETAILS { public int cbStruct; public uint dwControlID, cChannels; public IntPtr hwndOwner; public int cbDetails; public IntPtr paDetails; }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
    struct LISTTEXT { public uint dwParam1, dwParam2; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string szName; }

    [DllImport("winmm.dll")] static extern int mixerGetNumDevs();
    [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern int mixerGetDevCaps(int id, ref MIXERCAPS c, int sz);
    [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern int mixerGetLineInfo(IntPtr h, ref MIXERLINE l, uint f);
    [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern int mixerGetLineControls(IntPtr h, ref MIXERLINECONTROLS c, uint f);
    [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern int mixerGetControlDetails(IntPtr h, ref MIXERCONTROLDETAILS d, uint f);

    const uint MIXER_OBJECTF_MIXER = 0, GETLINEINFOF_DESTINATION = 0, GETLINEINFOF_SOURCE = 1, GETLINECONTROLSF_ALL = 0;
    const uint DETAILSF_VALUE = 0, DETAILSF_LISTTEXT = 1;

    static void Main()
    {
        int n = mixerGetNumDevs();
        for (int m = 0; m < n; m++)
        {
            var caps = new MIXERCAPS(); mixerGetDevCaps(m, ref caps, Marshal.SizeOf(caps));
            Console.WriteLine("MIXER {0}: {1} (dest {2})", m, caps.szPname, caps.cDestinations);
            for (uint d = 0; d < caps.cDestinations; d++)
            {
                var line = new MIXERLINE(); line.cbStruct = Marshal.SizeOf(line); line.dwDestination = d;
                mixerGetLineInfo((IntPtr)m, ref line, GETLINEINFOF_DESTINATION);
                Console.WriteLine("  DEST {0}: '{1}' type=0x{2:X} ch={3} conns={4}", d, line.szName, line.dwComponentType, line.cChannels, line.cConnections);
                DumpControls(m, line, "    ");
                for (uint s = 0; s < line.cConnections; s++)
                {
                    var src = new MIXERLINE(); src.cbStruct = Marshal.SizeOf(src); src.dwDestination = d; src.dwSource = s;
                    mixerGetLineInfo((IntPtr)m, ref src, GETLINEINFOF_SOURCE);
                    Console.WriteLine("    SRC {0}: '{1}' type=0x{2:X}", s, src.szName, src.dwComponentType);
                    DumpControls(m, src, "      ");
                }
            }
        }
    }

    static void DumpControls(int m, MIXERLINE line, string ind)
    {
        if (line.cControls == 0) return;
        int csz = Marshal.SizeOf(typeof(MIXERCONTROL));
        var lc = new MIXERLINECONTROLS { cbStruct = Marshal.SizeOf(typeof(MIXERLINECONTROLS)), dwLineID = line.dwLineID, cControls = line.cControls, cbmxctrl = csz };
        lc.pamxctrl = Marshal.AllocHGlobal(csz * (int)line.cControls);
        if (mixerGetLineControls((IntPtr)m, ref lc, GETLINECONTROLSF_ALL) == 0)
            for (int i = 0; i < line.cControls; i++)
            {
                var c = (MIXERCONTROL)Marshal.PtrToStructure(new IntPtr(lc.pamxctrl.ToInt64() + i * csz), typeof(MIXERCONTROL));
                Console.WriteLine("{0}CTRL id={1} '{2}' type=0x{3:X8} items={4} range={5}..{6} value={7}", ind, c.dwControlID, c.szName, c.dwControlType, c.cMultipleItems, c.lMinimum, c.lMaximum, ReadValue(m, c));
                if (c.cMultipleItems > 0)
                {
                    int tsz = Marshal.SizeOf(typeof(LISTTEXT));
                    var det = new MIXERCONTROLDETAILS { cbStruct = Marshal.SizeOf(typeof(MIXERCONTROLDETAILS)), dwControlID = c.dwControlID, cChannels = 1, hwndOwner = (IntPtr)c.cMultipleItems, cbDetails = tsz };
                    det.paDetails = Marshal.AllocHGlobal(tsz * (int)c.cMultipleItems);
                    if (mixerGetControlDetails((IntPtr)m, ref det, DETAILSF_LISTTEXT) == 0)
                        for (int k = 0; k < c.cMultipleItems; k++)
                        {
                            var t = (LISTTEXT)Marshal.PtrToStructure(new IntPtr(det.paDetails.ToInt64() + k * tsz), typeof(LISTTEXT));
                            Console.WriteLine("{0}  item {1}: '{2}' (line {3})", ind, k, t.szName, t.dwParam1);
                        }
                    Marshal.FreeHGlobal(det.paDetails);
                }
            }
        Marshal.FreeHGlobal(lc.pamxctrl);
    }

    static string ReadValue(int m, MIXERCONTROL c)
    {
        int items = c.cMultipleItems > 0 ? (int)c.cMultipleItems : 1;
        var det = new MIXERCONTROLDETAILS { cbStruct = Marshal.SizeOf(typeof(MIXERCONTROLDETAILS)), dwControlID = c.dwControlID, cChannels = 1, hwndOwner = (IntPtr)(c.cMultipleItems), cbDetails = 4 };
        det.paDetails = Marshal.AllocHGlobal(4 * items);
        string r = "?";
        if (mixerGetControlDetails((IntPtr)m, ref det, DETAILSF_VALUE) == 0)
        {
            var vals = new int[items]; Marshal.Copy(det.paDetails, vals, 0, items); r = string.Join(",", vals);
        }
        Marshal.FreeHGlobal(det.paDetails);
        return r;
    }
}
