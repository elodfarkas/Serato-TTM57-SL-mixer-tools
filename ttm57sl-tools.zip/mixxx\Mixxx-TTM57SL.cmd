@echo off
rem Rane TTM 57SL + Mixxx: route the phono (timecode) inputs to USB Line 1/2 so vinyl control works
rem with the channel switches on D1/D2, then start Mixxx. Record source byte: low nibble Line 1, high nibble Line 2.
rem Run from the build output folder (bin), next to TtmCmd.exe.
"%~dp0TtmCmd.exe" 66
start "" "C:\Program Files\Mixxx\mixxx.exe"
