"""Record N seconds from the TTM57SL Line 1 and Line 2 WDM-KS inputs (via Mixxx's portaudio.dll)
into a 4-channel sweep_<tag>.wav so analyze_sweep.py can check it for timecode.
Usage: py -I pa_capture.py <out_dir> <tag> [seconds]"""
import ctypes, os, struct, sys, threading, wave

os.add_dll_directory(r"C:\Program Files\Mixxx")
pa = ctypes.CDLL(r"C:\Program Files\Mixxx\portaudio.dll")


class DevInfo(ctypes.Structure):
    _fields_ = [("structVersion", ctypes.c_int), ("name", ctypes.c_char_p), ("hostApi", ctypes.c_int),
                ("maxIn", ctypes.c_int), ("maxOut", ctypes.c_int),
                ("lli", ctypes.c_double), ("llo", ctypes.c_double), ("hli", ctypes.c_double), ("hlo", ctypes.c_double),
                ("sr", ctypes.c_double)]


class ApiInfo(ctypes.Structure):
    _fields_ = [("structVersion", ctypes.c_int), ("type", ctypes.c_int), ("name", ctypes.c_char_p)]


class StreamParams(ctypes.Structure):
    _fields_ = [("device", ctypes.c_int), ("channelCount", ctypes.c_int), ("sampleFormat", ctypes.c_ulong),
                ("suggestedLatency", ctypes.c_double), ("hostApiSpecificStreamInfo", ctypes.c_void_p)]


pa.Pa_GetDeviceInfo.restype = ctypes.POINTER(DevInfo)
pa.Pa_GetHostApiInfo.restype = ctypes.POINTER(ApiInfo)
pa.Pa_GetErrorText.restype = ctypes.c_char_p
PA_INT16 = 0x8


def find(line):
    for i in range(pa.Pa_GetDeviceCount()):
        d = pa.Pa_GetDeviceInfo(i).contents
        api = pa.Pa_GetHostApiInfo(d.hostApi).contents.name.decode()
        if os.environ.get("PA_API", "WDM-KS") in api and d.maxIn > 0 and ("TTM57SL Line %d" % line) in d.name.decode("utf-8", "replace"):
            return i
    return None


CALLBACK = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong,
                            ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p)


def record(dev, frames, out):
    # Callback mode: WDM-KS in this PortAudio build rejects blocking streams.
    p = StreamParams(dev, 2, PA_INT16, pa.Pa_GetDeviceInfo(dev).contents.lli, None)
    data, done = [], threading.Event()

    def cb(inp, outp, count, tinfo, flags, user):
        if inp:
            data.extend(ctypes.cast(inp, ctypes.POINTER(ctypes.c_int16))[:count * 2])
        if len(data) >= frames * 2:
            done.set(); return 1
        return 0

    fn = CALLBACK(cb)
    stream = ctypes.c_void_p()
    err = pa.Pa_OpenStream(ctypes.byref(stream), ctypes.byref(p), None, ctypes.c_double(44100), 0, 0, fn, None)
    if err:
        out.append(None); print("open", dev, pa.Pa_GetErrorText(err)); return
    pa.Pa_StartStream(stream)
    done.wait(frames / 44100 + 5)
    pa.Pa_StopStream(stream); pa.Pa_CloseStream(stream)
    out.append((data + [0] * (frames * 2))[:frames * 2])


def main():
    out_dir, tag = sys.argv[1], sys.argv[2]
    secs = float(sys.argv[3]) if len(sys.argv) > 3 else 3
    frames = int(44100 * secs)
    pa.Pa_Initialize()
    devs = [find(1), find(2)]
    print("devices", devs)
    results = [[], []]
    threads = [threading.Thread(target=record, args=(d, frames, results[k])) for k, d in enumerate(devs) if d is not None]
    for t in threads: t.start()
    for t in threads: t.join()
    pa.Pa_Terminate()
    chans = [r[0] if r and r[0] else [0] * (frames * 2) for r in results]
    with wave.open(os.path.join(out_dir, "sweep_%s.wav" % tag), "wb") as w:
        w.setnchannels(4); w.setsampwidth(2); w.setframerate(44100)
        data = []
        for i in range(frames):
            data += [chans[0][2 * i], chans[0][2 * i + 1], chans[1][2 * i], chans[1][2 * i + 1]]
        w.writeframes(struct.pack("<%dh" % len(data), *data))
    print("saved", tag)


if __name__ == "__main__":
    main()
