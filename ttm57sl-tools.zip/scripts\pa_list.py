import ctypes, os

os.add_dll_directory(r"C:\Program Files\Mixxx")
pa = ctypes.CDLL(r"C:\Program Files\Mixxx\portaudio.dll")


class DevInfo(ctypes.Structure):
    _fields_ = [("structVersion", ctypes.c_int), ("name", ctypes.c_char_p), ("hostApi", ctypes.c_int),
                ("maxIn", ctypes.c_int), ("maxOut", ctypes.c_int),
                ("lli", ctypes.c_double), ("llo", ctypes.c_double), ("hli", ctypes.c_double), ("hlo", ctypes.c_double),
                ("sr", ctypes.c_double)]


class ApiInfo(ctypes.Structure):
    _fields_ = [("structVersion", ctypes.c_int), ("type", ctypes.c_int), ("name", ctypes.c_char_p)]


pa.Pa_GetDeviceInfo.restype = ctypes.POINTER(DevInfo)
pa.Pa_GetHostApiInfo.restype = ctypes.POINTER(ApiInfo)
print("init", pa.Pa_Initialize())
for i in range(pa.Pa_GetDeviceCount()):
    d = pa.Pa_GetDeviceInfo(i).contents
    api = pa.Pa_GetHostApiInfo(d.hostApi).contents.name.decode("utf-8", "replace")
    print(f"{i:3d} [{api}] in={d.maxIn} out={d.maxOut} sr={d.sr:.0f} {d.name.decode('utf-8', 'replace')}")
pa.Pa_Terminate()
