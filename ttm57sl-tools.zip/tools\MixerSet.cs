using System;
using System.Runtime.InteropServices;

// Unmutes and sets to full volume every control on winmm mixers whose name contains the given text.
// Usage: MixerSet.exe "TTM57SL"
class MixerSet
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
    struct MIXERCAPS { public ushort wMid, wPid; public uint vDriverVersion; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szPname; public uint fdwSupport, cDestinations; }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
    struct MIXERLINE
    {
        public int cbStruct; public uint dwDestination, dwSource, dwLineID, fdwLine; public IntPtr dwUser; public uint dwComponentType, cChannels, cConnections, cControls;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)] public string szShortName; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string szName;
        public uint dwType, dwDeviceID; public ushort wMid, wPid; public uint vDriverVersion; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szPname;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
    struct MIXERCONTROL
    {
        public int cbStruct; public uint dwControlID, dwControlType, fdwControl, cMultipleItems;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)] public string szShortName; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string szName;
        public int lMinimum, lMaximum; [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)] public int[] r1; public uint cSteps; [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)] public int[] r2;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)] struct MIXERLINECONTROLS { public int cbStruct; public uint dwLineID, dwControl, cControls; public int cbmxctrl; public IntPtr pamxctrl; }
    [StructLayout(LayoutKind.Sequential, Pack = 1)] struct MIXERCONTROLDETAILS { public int cbStruct; public uint dwControlID, cChannels; public IntPtr hwndOwner; public int cbDetails; public IntPtr paDetails; }

    [DllImport("winmm.dll")] static extern int mixerGetNumDevs();
    [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern int mixerGetDevCaps(int id, ref MIXERCAPS c, int sz);
    [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern int mixerGetLineInfo(IntPtr h, ref MIXERLINE l, uint f);
    [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern int mixerGetLineControls(IntPtr h, ref MIXERLINECONTROLS c, uint f);
    [DllImport("winmm.dll")] static extern int mixerSetControlDetails(IntPtr h, ref MIXERCONTROLDETAILS d, uint f);

    const uint MUTE = 0x20010002, VOLUME = 0x50030001;

    static void Main(string[] args)
    {
        for (int m = 0; m < mixerGetNumDevs(); m++)
        {
            var caps = new MIXERCAPS(); mixerGetDevCaps(m, ref caps, Marshal.SizeOf(caps));
            if (!caps.szPname.Contains(args[0])) continue;
            for (uint d = 0; d < caps.cDestinations; d++)
            {
                var line = new MIXERLINE { cbStruct = Marshal.SizeOf(typeof(MIXERLINE)), dwDestination = d };
                mixerGetLineInfo((IntPtr)m, ref line, 0);
                Apply(m, caps.szPname, line);
                for (uint s = 0; s < line.cConnections; s++)
                {
                    var src = new MIXERLINE { cbStruct = Marshal.SizeOf(typeof(MIXERLINE)), dwDestination = d, dwSource = s };
                    mixerGetLineInfo((IntPtr)m, ref src, 1);
                    Apply(m, caps.szPname, src);
                }
            }
        }
    }

    static void Apply(int m, string dev, MIXERLINE line)
    {
        int csz = Marshal.SizeOf(typeof(MIXERCONTROL));
        var lc = new MIXERLINECONTROLS { cbStruct = Marshal.SizeOf(typeof(MIXERLINECONTROLS)), dwLineID = line.dwLineID, cControls = line.cControls, cbmxctrl = csz };
        lc.pamxctrl = Marshal.AllocHGlobal(csz * (int)Math.Max(1, line.cControls));
        if (line.cControls > 0 && mixerGetLineControls((IntPtr)m, ref lc, 0) == 0)
            for (int i = 0; i < line.cControls; i++)
            {
                var c = (MIXERCONTROL)Marshal.PtrToStructure(new IntPtr(lc.pamxctrl.ToInt64() + i * csz), typeof(MIXERCONTROL));
                int value;
                if (c.dwControlType == MUTE) value = 0; else if (c.dwControlType == VOLUME) value = c.lMaximum; else continue;
                var det = new MIXERCONTROLDETAILS { cbStruct = Marshal.SizeOf(typeof(MIXERCONTROLDETAILS)), dwControlID = c.dwControlID, cChannels = 1, cbDetails = 4 };
                det.paDetails = Marshal.AllocHGlobal(4); Marshal.WriteInt32(det.paDetails, value);
                int r = mixerSetControlDetails((IntPtr)m, ref det, 0);
                Console.WriteLine("{0} / {1}: {2} = {3} ({4})", dev, line.szName, c.dwControlType == MUTE ? "mute" : "volume", value, r == 0 ? "ok" : "err " + r);
                Marshal.FreeHGlobal(det.paDetails);
            }
        Marshal.FreeHGlobal(lc.pamxctrl);
    }
}
