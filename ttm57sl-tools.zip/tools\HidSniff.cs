using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;

// Usage: HidSniff.exe <seconds> [logfile]
// Opens VID_13E5&PID_0003 HID interface, prints caps, then logs every input report that differs from the previous one.
class HidSniff
{
    [StructLayout(LayoutKind.Sequential)] struct SP_DEVICE_INTERFACE_DATA { public int cbSize; public Guid g; public int flags; public IntPtr res; }
    [StructLayout(LayoutKind.Sequential)] struct HIDD_ATTRIBUTES { public int Size; public ushort VendorID, ProductID, VersionNumber; }
    [StructLayout(LayoutKind.Sequential)] struct HIDP_CAPS {
        public ushort Usage, UsagePage, InputReportByteLength, OutputReportByteLength, FeatureReportByteLength;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)] public ushort[] Reserved;
        public ushort NumberLinkCollectionNodes, NumberInputButtonCaps, NumberInputValueCaps, NumberInputDataIndices,
            NumberOutputButtonCaps, NumberOutputValueCaps, NumberOutputDataIndices, NumberFeatureButtonCaps, NumberFeatureValueCaps, NumberFeatureDataIndices;
    }
    [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
    [DllImport("hid.dll")] static extern bool HidD_GetAttributes(SafeFileHandle h, ref HIDD_ATTRIBUTES a);
    [DllImport("hid.dll")] static extern bool HidD_GetPreparsedData(SafeFileHandle h, out IntPtr p);
    [DllImport("hid.dll")] static extern int HidP_GetCaps(IntPtr p, out HIDP_CAPS c);
    [DllImport("hid.dll")] static extern bool HidD_FreePreparsedData(IntPtr p);
    [DllImport("setupapi.dll", SetLastError = true)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr h, int f);
    [DllImport("setupapi.dll", SetLastError = true)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr s, IntPtr d, ref Guid g, int i, ref SP_DEVICE_INTERFACE_DATA did);
    [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Auto)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr s, ref SP_DEVICE_INTERFACE_DATA did, IntPtr buf, int size, out int req, IntPtr dev);
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)] static extern SafeFileHandle CreateFile(string n, uint a, uint s, IntPtr sa, uint c, uint f, IntPtr t);

    static void Main(string[] args)
    {
        int seconds = args.Length > 0 ? int.Parse(args[0]) : 5;
        TextWriter log = args.Length > 1 ? (TextWriter)new StreamWriter(args[1], false) { AutoFlush = true } : Console.Out;
        Guid hg; HidD_GetHidGuid(out hg);
        IntPtr set = SetupDiGetClassDevs(ref hg, IntPtr.Zero, IntPtr.Zero, 0x12);
        string path = null;
        for (int i = 0; ; i++)
        {
            var did = new SP_DEVICE_INTERFACE_DATA(); did.cbSize = Marshal.SizeOf(did);
            if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref hg, i, ref did)) break;
            int req; SetupDiGetDeviceInterfaceDetail(set, ref did, IntPtr.Zero, 0, out req, IntPtr.Zero);
            IntPtr buf = Marshal.AllocHGlobal(req);
            Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);
            if (SetupDiGetDeviceInterfaceDetail(set, ref did, buf, req, out req, IntPtr.Zero))
            {
                string p = Marshal.PtrToStringAuto(new IntPtr(buf.ToInt64() + 4));
                if (p.ToLower().Contains("vid_13e5&pid_0003")) path = p;
            }
            Marshal.FreeHGlobal(buf);
        }
        if (path == null) { Console.Error.WriteLine("TTM57SL HID not found"); Environment.Exit(1); }
        Console.WriteLine("Path: " + path);
        var h = CreateFile(path, 0xC0000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
        if (h.IsInvalid) h = CreateFile(path, 0x80000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
        if (h.IsInvalid) { Console.Error.WriteLine("open failed " + Marshal.GetLastWin32Error()); Environment.Exit(2); }
        IntPtr pp; HidD_GetPreparsedData(h, out pp); HIDP_CAPS caps; HidP_GetCaps(pp, out caps); HidD_FreePreparsedData(pp);
        Console.WriteLine("UsagePage {0:X4} Usage {1:X4} In {2} Out {3} Feat {4} InBtnCaps {5} InValCaps {6}",
            caps.UsagePage, caps.Usage, caps.InputReportByteLength, caps.OutputReportByteLength, caps.FeatureReportByteLength,
            caps.NumberInputButtonCaps, caps.NumberInputValueCaps);
        var fs = new FileStream(h, FileAccess.Read, caps.InputReportByteLength, false);
        byte[] prev = null; var start = DateTime.Now; int count = 0;
        var t = new Thread(() => {
            byte[] b = new byte[caps.InputReportByteLength];
            while (true)
            {
                int n; try { n = fs.Read(b, 0, b.Length); } catch (Exception e) { Console.Error.WriteLine(e.Message); return; }
                count++;
                bool diff = prev == null; if (!diff) for (int k = 0; k < n; k++) if (b[k] != prev[k]) { diff = true; break; }
                if (diff)
                {
                    var sb = new StringBuilder(); sb.AppendFormat("{0,8:F3} ", (DateTime.Now - start).TotalSeconds);
                    for (int k = 0; k < n; k++) sb.AppendFormat("{0:X2} ", b[k]);
                    lock (log) log.WriteLine(sb.ToString().TrimEnd());
                    prev = (byte[])b.Clone();
                }
            }
        }) { IsBackground = true };
        t.Start();
        Thread.Sleep(seconds * 1000);
        lock (log) log.WriteLine("# reports read: " + count);
        log.Flush();
    }
}
