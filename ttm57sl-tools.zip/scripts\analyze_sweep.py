"""Spectral summary of sweep_XX.wav captures: per input pair, level, dominant frequency,
share of energy in the 900-1100 Hz timecode band, and L/R quadrature (Serato CV02 carrier is
1 kHz with L and R ~90 degrees apart)."""
import cmath, glob, math, os, struct, sys, wave

N = 8192


def fft(x):
    n = len(x)
    if n == 1:
        return x
    even, odd = fft(x[0::2]), fft(x[1::2])
    out = [0j] * n
    for k in range(n // 2):
        t = cmath.exp(-2j * math.pi * k / n) * odd[k]
        out[k], out[k + n // 2] = even[k] + t, even[k] - t
    return out


def analyse(sig, sr):
    seg = sig[len(sig) // 4: len(sig) // 4 + N]
    rms = math.sqrt(sum(s * s for s in seg) / len(seg)) + 1e-12
    win = [s * (0.5 - 0.5 * math.cos(2 * math.pi * i / (N - 1))) for i, s in enumerate(seg)]
    spec = fft(win)[: N // 2]
    power = [abs(c) ** 2 for c in spec]
    total = sum(power[2:]) + 1e-30
    peak = max(range(2, N // 2), key=lambda k: power[k])
    lo, hi = int(900 * N / sr), int(1100 * N / sr)
    band = sum(power[lo:hi + 1]) / total
    return 20 * math.log10(rms), peak * sr / N, band, spec[peak]


def main(folder):
    for path in sorted(glob.glob(os.path.join(folder, "sweep_*.wav"))):
        with wave.open(path) as w:
            ch, sr, n = w.getnchannels(), w.getframerate(), w.getnframes()
            raw = struct.unpack("<%dh" % (n * ch), w.readframes(n))
        chans = [[raw[i * ch + c] / 32768.0 for i in range(n)] for c in range(ch)]
        parts = []
        for pair in range(ch // 2):
            l, r = analyse(chans[2 * pair], sr), analyse(chans[2 * pair + 1], sr)
            phase = math.degrees(cmath.phase(l[3] / r[3])) if abs(r[3]) > 0 else 0
            tc = l[0] > -70 and l[2] > 0.3 and r[2] > 0.3
            parts.append("Line%d %6.1f/%6.1f dB peak %5.0f/%5.0f Hz band %3.0f%%/%3.0f%% dphi %4.0f %s" % (
                pair + 1, l[0], r[0], l[1], r[1], 100 * l[2], 100 * r[2], phase, "<< TIMECODE" if tc else ""))
        print(os.path.basename(path)[6:8], " | ".join(parts))


if __name__ == "__main__":
    main(sys.argv[1])
