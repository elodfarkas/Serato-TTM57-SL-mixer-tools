# Rane TTM 57SL USB notes

Everything here was observed on one mixer (bcdDevice 3.20, serial string `TTM.01.00`) on Windows 11,
by logging what Rane's own ASIO driver (`TTM57SLASIO.dll` 1.0.0.5, build 105) sends to the mixer and by
measuring the audio that comes back. Treat it as field notes, not a specification.

## Two USB personalities

| Mode | VID:PID | Windows driver | What you get |
|---|---|---|---|
| Class-compliant (power-on default) | `13E5:0003` | in-box `usbaudio` + `HidUsb` | 2 stereo USB Audio devices, "TTM57SL Line 1" and "TTM57SL Line 2" (16-bit, 44.1 kHz, in and out), plus a vendor HID interface (#6, usage page `FF00`, 64-byte reports, interrupt EP `0x83` IN / `0x03` OUT) |
| Serato mode | `13E5:8003` | `TTM57SLUsb.sys` (Serato/Cristalink) | Isochronous pipes 1, 2, 4, 5 (4 in / 4 out audio) and interrupt pipe 6 (`InterruptPipe\6\0`, `\6\1`) |

In class-compliant mode the HID interface sends nothing on its own, even while you move every control.

## Commands

All packets are 64 bytes. Over the HID interface they are written as a 65-byte output report (report ID `00` first).

### `0x1A`: switch to Serato mode

```
1A 00 00 ... 00
```

Sent by the ASIO driver over HID in class-compliant mode. About 1 s later the mixer re-enumerates as `13E5:8003`.
It stays in Serato mode until it is powered off. Closing the host does not switch it back.

### `0x18`: settings (record source)

```
offset 0      : 18
offset 37     : record source byte
everything else 00 (as sent by the driver with default settings)
```

The ASIO driver sends this once at startup over `InterruptPipe\6\1`, with byte 37 = `22`.
The same packet is **also accepted over the HID interface in class-compliant mode** (the mixer stays in `0003` mode).

Byte 37: **low nibble = Line 1 record source, high nibble = Line 2 record source.**

Measured on Line 1 with turntable 1 playing Serato CV02 timecode into channel 1's phono input and the channel
input switch on the digital (D1) position:

| Low nibble | What USB Line 1 records |
|---|---|
| 0, 1, 3, 4 | digital silence |
| 2 (driver default), 5 | analog noise floor; the program channel after the input switch, so no timecode while on D1 |
| **6 to F** | **the phono signal, independent of the input switch**: about −45 dBFS via WDM-KS, about 49 % of the energy at 1 kHz with L/R in quadrature (Serato CV02). There is also a strong component near 21 kHz on this path. |

`66` gives timecode on Line 1 while the channel plays the computer's audio from D1. That is the normal DVS setup.
**The high nibble (Line 2) is assumed to behave the same way but has not been verified with a second turntable.**

The ASIO driver's control panel offers "Line 1/2 Record Source": PGM 1/2 pre-fader or post-fader, or Aux Bus, plus a
±12 dB level. Changing it in the panel sends nothing immediately. The values it uses, and the record-level fields, are not decoded yet.

## Serato-mode pipe traffic seen at driver start

```
DeviceIoControl 0x00224004  in 0A 00 00 00 05 00 00 00 14 00 00 00 00 00 00 00   (iso pipes, repeated per transfer)
DeviceIoControl 0x0022400C  in 0A 00 00 00 0A 00 00 00
DeviceIoControl 0x00228008  in 14 00 00 00 00 00 00 00                             (interrupt pipes)
WriteFile       InterruptPipe\6\1  18 ... 22 ...                                    (settings, see above)
WriteFileEx     iso OUT, 1804-byte transfers starting with B0 00 ...                (audio)
```

ASIO channel names in Serato mode: inputs "TTM57SL Mix L/R" ×2, outputs "TTM 57SL 1 L/R" and "TTM 57SL 2 L/R",
16-bit, 441-frame buffers.

## Not done

- The SL section controls (FX, cue and loop buttons, etc.) are expected on interrupt pipe 6 in Serato mode. They are not decoded.
- Record level, the Aux Bus source, and the meaning of other bytes in the `0x18` packet.
- Line 2 / high-nibble verification.
- The origin of the ~21 kHz component on the phono path.
