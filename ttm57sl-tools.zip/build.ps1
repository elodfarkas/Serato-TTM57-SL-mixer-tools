# Builds all tools with the C# compiler that ships with Windows (.NET Framework 4.x). Output: .\bin
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$bin = Join-Path $root 'bin'
New-Item -ItemType Directory -Force $bin | Out-Null
$csc64 = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$csc32 = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"

foreach ($tool in 'TtmCmd', 'HidSniff', 'MixerDump', 'MixerSet') {
    & $csc64 /nologo /platform:x64 "/out:$bin\$tool.exe" "$root\tools\$tool.cs"
    if ($LASTEXITCODE) { throw "build failed: $tool" }
}

# The Rane ASIO driver is 32-bit, so its host must be x86.
& $csc32 /nologo /platform:x86 /target:winexe /r:System.Windows.Forms.dll /r:System.Drawing.dll "/out:$bin\AsioHost.exe" "$root\tools\AsioHost.cs"
if ($LASTEXITCODE) { throw 'build failed: AsioHost' }

# Clear IMAGE_DLLCHARACTERISTICS_NX_COMPAT: the driver's control panel uses ATL window thunks that crash under DEP.
$exe = "$bin\AsioHost.exe"
$bytes = [IO.File]::ReadAllBytes($exe)
$off = [BitConverter]::ToInt32($bytes, 0x3C) + 24 + 70
$flags = [BitConverter]::ToUInt16($bytes, $off) -band (-bnot 0x0100)
[BitConverter]::GetBytes([uint16]$flags)[0..1] | ForEach-Object -Begin { $i = 0 } -Process { $bytes[$off + $i] = $_; $i++ }
[IO.File]::WriteAllBytes($exe, $bytes)

Copy-Item "$root\mixxx\Mixxx-TTM57SL.cmd" $bin -Force
Write-Host "Built into $bin"
