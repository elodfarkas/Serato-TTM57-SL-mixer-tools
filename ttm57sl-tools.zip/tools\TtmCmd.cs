using System;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

// Usage: TtmCmd.exe <recordSourceByte hex, e.g. 66>
// Sends the TTM57SL 0x18 settings packet (as seen from the Rane ASIO driver) over the class-compliant
// HID interface (VID_13E5&PID_0003 MI_06). Byte 37 of the packet carries the record source:
// low nibble = Line 1, high nibble = Line 2 (2 = default/program, 6+ = phono control signal).
class TtmCmd
{
    [StructLayout(LayoutKind.Sequential)] struct SP_DEVICE_INTERFACE_DATA { public int cbSize; public Guid g; public int flags; public IntPtr res; }
    [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
    [DllImport("setupapi.dll", SetLastError = true)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr h, int f);
    [DllImport("setupapi.dll", SetLastError = true)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr s, IntPtr d, ref Guid g, int i, ref SP_DEVICE_INTERFACE_DATA did);
    [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Auto)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr s, ref SP_DEVICE_INTERFACE_DATA did, IntPtr buf, int size, out int req, IntPtr dev);
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)] static extern SafeFileHandle CreateFile(string n, uint a, uint s, IntPtr sa, uint c, uint f, IntPtr t);

    static string FindPath()
    {
        Guid hg; HidD_GetHidGuid(out hg);
        IntPtr set = SetupDiGetClassDevs(ref hg, IntPtr.Zero, IntPtr.Zero, 0x12);
        for (int i = 0; ; i++)
        {
            var did = new SP_DEVICE_INTERFACE_DATA(); did.cbSize = Marshal.SizeOf(did);
            if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref hg, i, ref did)) return null;
            int req; SetupDiGetDeviceInterfaceDetail(set, ref did, IntPtr.Zero, 0, out req, IntPtr.Zero);
            IntPtr buf = Marshal.AllocHGlobal(req); Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);
            string p = SetupDiGetDeviceInterfaceDetail(set, ref did, buf, req, out req, IntPtr.Zero) ? Marshal.PtrToStringAuto(new IntPtr(buf.ToInt64() + 4)) : "";
            Marshal.FreeHGlobal(buf);
            if (p.ToLower().Contains("vid_13e5&pid_0003")) return p;
        }
    }

    static int Main(string[] args)
    {
        byte source = Convert.ToByte(args[0], 16);
        string path = FindPath();
        for (int i = 0; path == null && i < 20; i++) { System.Threading.Thread.Sleep(500); path = FindPath(); }
        if (path == null) { Console.Error.WriteLine("TTM57SL class-compliant HID interface not found (is the mixer in Serato mode?)"); return 1; }
        var h = CreateFile(path, 0xC0000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
        if (h.IsInvalid) { Console.Error.WriteLine("open failed " + Marshal.GetLastWin32Error()); return 2; }
        var report = new byte[65];           // report ID 0 + 64-byte packet
        report[1] = 0x18; report[1 + 37] = source;
        using (var fs = new FileStream(h, FileAccess.ReadWrite, 65, false)) fs.Write(report, 0, report.Length);
        Console.WriteLine("sent 0x18 settings, record source 0x" + source.ToString("X2"));
        return 0;
    }
}
