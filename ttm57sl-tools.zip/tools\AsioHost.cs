using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

// 32-bit research host for Rane's TTM57SLASIO.dll (ships with Serato Scratch Live; not included here).
// Loads the driver without COM registration (CLSID found by probing DllGetClassObject), hooks its kernel32
// imports to log the commands it sends to the mixer, streams all 4 inputs with live meters, can open the
// driver's control panel and can sweep the record-source byte of the 0x18 settings packet, saving a WAV per value.
// Usage: AsioHost.exe <path to TTM57SLASIO.dll> <log file> [panel]
// Note: the driver's dialog uses ATL thunks, so the built exe must have the NX_COMPAT flag cleared (build.ps1 does it).
class AsioHost
{
    [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Ansi)] static extern IntPtr LoadLibraryA(string n);
    [DllImport("kernel32", CharSet = CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr m, string n);
    [DllImport("kernel32")] static extern IntPtr GetModuleHandleA(string n);
    [DllImport("kernel32")] static extern bool VirtualProtect(IntPtr a, UIntPtr s, uint p, out uint o);
    [DllImport("ole32")] static extern int CoInitialize(IntPtr r);

    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int DllGetClassObjectFn(ref Guid clsid, ref Guid iid, out IntPtr ppv);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int CreateInstanceFn(IntPtr self, IntPtr outer, ref Guid iid, out IntPtr ppv);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int InitFn(IntPtr self, IntPtr sysHandle);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate void GetNameFn(IntPtr self, StringBuilder name);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int GetChannelsFn(IntPtr self, out int ins, out int outs);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int VoidFn(IntPtr self);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate void ErrFn(IntPtr self, StringBuilder msg);

    [UnmanagedFunctionPointer(CallingConvention.StdCall, SetLastError = true)] delegate bool WriteFileFn(IntPtr h, IntPtr buf, uint n, IntPtr written, IntPtr ovl);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate bool WriteFileExFn(IntPtr h, IntPtr buf, uint n, IntPtr ovl, IntPtr cb);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate bool ReadFileExFn(IntPtr h, IntPtr buf, uint n, IntPtr ovl, IntPtr cb);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate IntPtr CreateFileAFn(IntPtr name, uint acc, uint share, IntPtr sa, uint disp, uint flags, IntPtr tmpl);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate bool DeviceIoControlFn(IntPtr h, uint code, IntPtr inb, uint inn, IntPtr outb, uint outn, IntPtr ret, IntPtr ovl);

    static WriteFileFn realWrite, hookWrite; static WriteFileExFn realWriteEx, hookWriteEx; static ReadFileExFn realReadEx, hookReadEx;
    static CreateFileAFn realCreate, hookCreate; static DeviceIoControlFn realIoctl, hookIoctl;
    static TextWriter log; static int ioctlLogged; static readonly object lk = new object(); static DateTime t0 = DateTime.Now;

    static void Log(string s) { lock (lk) { log.WriteLine("{0,8:F3} {1}", (DateTime.Now - t0).TotalSeconds, s); } Console.WriteLine(s); }
    static string Hex(IntPtr p, uint n) { var b = new byte[n]; Marshal.Copy(p, b, 0, (int)n); return BitConverter.ToString(b).Replace("-", " "); }

    [STAThread]
    static void Main(string[] args)
    {
        string dll = args[0];
        log = new StreamWriter(args[1], false) { AutoFlush = true }; logDir = Path.GetDirectoryName(Path.GetFullPath(args[1]));
        CoInitialize(IntPtr.Zero);
        IntPtr mod = LoadLibraryA(dll);
        if (mod == IntPtr.Zero) { Log("LoadLibrary failed " + Marshal.GetLastWin32Error()); return; }
        HookImports(mod);

        var getCo = (DllGetClassObjectFn)Marshal.GetDelegateForFunctionPointer(GetProcAddress(mod, "DllGetClassObject"), typeof(DllGetClassObjectFn));
        Guid iidFactory = new Guid("00000001-0000-0000-C000-000000000046");
        byte[] img = File.ReadAllBytes(dll); Guid clsid = Guid.Empty; IntPtr factory = IntPtr.Zero;
        for (int off = 0; off + 16 <= img.Length; off += 4)
        {
            var gb = new byte[16]; Array.Copy(img, off, gb, 0, 16); var g = new Guid(gb);
            if (g == Guid.Empty || g == iidFactory) continue;
            if (getCo(ref g, ref iidFactory, out factory) == 0 && factory != IntPtr.Zero) { clsid = g; break; }
        }
        if (factory == IntPtr.Zero) { Log("CLSID not found"); return; }
        Log("CLSID {" + clsid.ToString().ToUpper() + "}");

        IntPtr fvt = Marshal.ReadIntPtr(factory);
        var create = (CreateInstanceFn)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(fvt, 3 * IntPtr.Size), typeof(CreateInstanceFn));
        IntPtr asio; int hr = create(factory, IntPtr.Zero, ref clsid, out asio);
        Log("CreateInstance hr=0x" + hr.ToString("X8"));
        if (asio == IntPtr.Zero) return;
        IntPtr vt = Marshal.ReadIntPtr(asio);
        Func<int, Type, Delegate> V = (i, t) => Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(vt, i * IntPtr.Size), t);

        var form = new Form { Text = "TTM57SL ASIO host", Width = 520, Height = 260 };
        var btn = new Button { Text = "Open TTM 57SL ASIO Control Panel", Dock = DockStyle.Top, Height = 40 };
        meter = new Label { Dock = DockStyle.Fill, Font = new System.Drawing.Font("Consolas", 11) };
        var sweepBtn = new Button { Text = "Start record-source sweep", Dock = DockStyle.Top, Height = 40 };
        sweepBtn.Click += (s, e) => { sweepBtn.Enabled = false; new Thread(Sweep) { IsBackground = true }.Start(); };
        form.Controls.Add(meter); form.Controls.Add(sweepBtn); form.Controls.Add(btn);
        form.Shown += (s, e) =>
        {
            int ok = ((InitFn)V(3, typeof(InitFn)))(asio, form.Handle);
            var sb = new StringBuilder(256);
            ((GetNameFn)V(4, typeof(GetNameFn)))(asio, sb);
            Log("init=" + ok + " name=" + sb);
            if (ok == 0) { var em = new StringBuilder(256); ((ErrFn)V(6, typeof(ErrFn)))(asio, em); Log("error: " + em); return; }
            int ins, outs; ((GetChannelsFn)V(9, typeof(GetChannelsFn)))(asio, out ins, out outs); Log("channels in=" + ins + " out=" + outs);
            StartStreaming(asio, V, ins, outs, form);
            if (args.Length > 2 && args[2] == "panel") form.BeginInvoke((Action)(() => btn.PerformClick()));
        };
        btn.Click += (s, e) => { Log("controlPanel -> " + ((VoidFn)V(21, typeof(VoidFn)))(asio)); };
        Application.Run(form);
        Log("exiting");
        ((VoidFn)V(2, typeof(VoidFn)))(asio);
    }

    [StructLayout(LayoutKind.Sequential)] struct BufferInfo { public int isInput, channelNum; public IntPtr buf0, buf1; }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)] struct ChannelInfo { public int channel, isInput, isActive, group, type; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string name; }
    [StructLayout(LayoutKind.Sequential)] struct Callbacks { public IntPtr bufferSwitch, sampleRateDidChange, asioMessage, bufferSwitchTimeInfo; }
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int GetBufSizeFn(IntPtr self, out int min, out int max, out int pref, out int gran);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int GetRateFn(IntPtr self, out double rate);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int ChanInfoFn(IntPtr self, ref ChannelInfo ci);
    [UnmanagedFunctionPointer(CallingConvention.ThisCall)] delegate int CreateBuffersFn(IntPtr self, IntPtr infos, int num, int size, IntPtr cb);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void BufferSwitchFn(int index, int direct);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void RateChangedFn(double rate);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int AsioMessageFn(int sel, int val, IntPtr msg, IntPtr opt);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate IntPtr TimeInfoFn(IntPtr p, int index, int direct);

    static Label meter; static BufferSwitchFn cbSwitch; static RateChangedFn cbRate; static AsioMessageFn cbMsg; static TimeInfoFn cbTime;
    static BufferInfo[] infos; static IntPtr infoMem; static int bufSize, nIn, sampleType; static double rate;
    static double[] sumSq, gRe, gIm; static int acc; static string[] chanNames; static Callbacks callbacks;

    // Streams all channels: outputs are silenced, inputs are metered (RMS + 1 kHz timecode carrier) once per second.
    static void StartStreaming(IntPtr asio, Func<int, Type, Delegate> V, int ins, int outs, Form form)
    {
        int min, max, pref, gran; ((GetBufSizeFn)V(11, typeof(GetBufSizeFn)))(asio, out min, out max, out pref, out gran);
        ((GetRateFn)V(13, typeof(GetRateFn)))(asio, out rate);
        bufSize = pref; nIn = ins; chanNames = new string[ins];
        for (int c = 0; c < ins; c++)
        {
            var ci = new ChannelInfo { channel = c, isInput = 1 }; ((ChanInfoFn)V(18, typeof(ChanInfoFn)))(asio, ref ci);
            chanNames[c] = ci.name; sampleType = ci.type; Log("in " + c + " '" + ci.name + "' type=" + ci.type);
        }
        for (int c = 0; c < outs; c++)
        {
            var ci = new ChannelInfo { channel = c, isInput = 0 }; ((ChanInfoFn)V(18, typeof(ChanInfoFn)))(asio, ref ci);
            Log("out " + c + " '" + ci.name + "' type=" + ci.type);
        }
        Log("buffer pref=" + pref + " rate=" + rate);
        int n = ins + outs; infos = new BufferInfo[n];
        for (int c = 0; c < n; c++) infos[c] = new BufferInfo { isInput = c < ins ? 1 : 0, channelNum = c < ins ? c : c - ins };
        int isz = Marshal.SizeOf(typeof(BufferInfo)); infoMem = Marshal.AllocHGlobal(isz * n);
        for (int c = 0; c < n; c++) Marshal.StructureToPtr(infos[c], new IntPtr(infoMem.ToInt64() + c * isz), false);
        sumSq = new double[ins]; gRe = new double[ins]; gIm = new double[ins];
        cbSwitch = (idx, direct) => OnBuffer(idx, ins, outs, form);
        cbRate = r => Log("rate changed " + r);
        cbMsg = (sel, val, msg, opt) => sel == 1 ? (val == 2 ? 1 : 0) : sel == 2 ? 2 : 0;
        cbTime = (p, idx, direct) => { OnBuffer(idx, ins, outs, form); return p; };
        callbacks = new Callbacks
        {
            bufferSwitch = Marshal.GetFunctionPointerForDelegate(cbSwitch), sampleRateDidChange = Marshal.GetFunctionPointerForDelegate(cbRate),
            asioMessage = Marshal.GetFunctionPointerForDelegate(cbMsg), bufferSwitchTimeInfo = Marshal.GetFunctionPointerForDelegate(cbTime)
        };
        IntPtr cbMem = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Callbacks))); Marshal.StructureToPtr(callbacks, cbMem, false);
        int hr = ((CreateBuffersFn)V(19, typeof(CreateBuffersFn)))(asio, infoMem, n, pref, cbMem);
        for (int c = 0; c < n; c++) infos[c] = (BufferInfo)Marshal.PtrToStructure(new IntPtr(infoMem.ToInt64() + c * isz), typeof(BufferInfo));
        Log("createBuffers=" + hr + " start=" + ((VoidFn)V(7, typeof(VoidFn)))(asio));
    }

    static double Sample(IntPtr buf, int i)
    {
        switch (sampleType)
        {
            case 16: return Marshal.ReadInt16(buf, i * 2) / 32768.0;
            case 17: return ((Marshal.ReadByte(buf, i * 3) | (Marshal.ReadByte(buf, i * 3 + 1) << 8) | ((sbyte)Marshal.ReadByte(buf, i * 3 + 2) << 16))) / 8388608.0;
            case 18: return Marshal.ReadInt32(buf, i * 4) / 2147483648.0;
            case 19: return BitConverter.ToSingle(BitConverter.GetBytes(Marshal.ReadInt32(buf, i * 4)), 0);
            default: return 0;
        }
    }

    static void OnBuffer(int idx, int ins, int outs, Form form)
    {
        int bytes = sampleType == 16 ? 2 : sampleType == 17 ? 3 : 4;
        var zero = new byte[bufSize * bytes];
        for (int c = ins; c < ins + outs; c++) Marshal.Copy(zero, 0, idx == 0 ? infos[c].buf0 : infos[c].buf1, zero.Length);
        // gRe = zero-crossing count, gIm = previous sample; timecode shows up as a ~1 kHz dominant frequency.
        for (int c = 0; c < ins; c++)
        {
            IntPtr b = idx == 0 ? infos[c].buf0 : infos[c].buf1;
            for (int i = 0; i < bufSize; i++)
            {
                double x = Sample(b, i);
                if (recTarget > 0 && recFrames + i < recTarget) rec[(recFrames + i) * ins + c] = (short)Math.Max(-32768, Math.Min(32767, x * 32768));
                sumSq[c] += x * x; if ((x >= 0) != (gIm[c] >= 0)) gRe[c]++; gIm[c] = x;
            }
        }
        if (recTarget > 0) recFrames = Math.Min(recTarget, recFrames + bufSize);
        acc += bufSize;
        if (acc < rate) return;
        var sb = new StringBuilder();
        for (int c = 0; c < ins; c++)
        {
            double rms = Math.Sqrt(sumSq[c] / acc), db = 20 * Math.Log10(rms + 1e-9), hz = gRe[c] / 2 * rate / acc;
            sb.AppendFormat("in{0} {1,-14} {2,7:F1} dBFS {3,6:F0} Hz {4}\r\n", c, chanNames[c], db, hz, db > -50 && hz > 700 && hz < 1400 ? "<< TIMECODE?" : "");
            sumSq[c] = gRe[c] = 0;
        }
        acc = 0;
        string text = sb.ToString();
        lock (lk) log.Write(text);
        try { form.BeginInvoke((Action)(() => meter.Text = text)); } catch { }
    }

    [DllImport("kernel32")] static extern IntPtr CreateEvent(IntPtr sa, bool manual, bool initial, string name);
    [DllImport("kernel32")] static extern uint WaitForSingleObject(IntPtr h, uint ms);
    static IntPtr settingsHandle; static byte[] settingsPacket;
    static string logDir; static volatile int recFrames, recTarget; static short[] rec;

    static void WriteWav(string path, short[] data, int ch, int sr)
    {
        using (var w = new BinaryWriter(File.Create(path)))
        {
            int bytes = data.Length * 2;
            w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write(36 + bytes); w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
            w.Write(16); w.Write((short)1); w.Write((short)ch); w.Write(sr); w.Write(sr * ch * 2); w.Write((short)(ch * 2)); w.Write((short)16);
            w.Write(Encoding.ASCII.GetBytes("data")); w.Write(bytes);
            foreach (var s in data) w.Write(s);
        }
    }

    // Re-sends the driver's 0x18 settings packet with a different value in its first non-zero payload byte
    // (0x22 by default, assumed to be the per-line record source), so the meters show which value routes the timecode.
    static void Sweep()
    {
        if (settingsPacket == null) { Log("SWEEP: no 0x18 packet captured"); return; }
        int idx = Array.FindIndex(settingsPacket, 1, b => b != 0);
        byte orig = settingsPacket[idx];
        Log("SWEEP start, byte index " + idx + " original 0x" + orig.ToString("X2"));
        var list = new System.Collections.Generic.List<byte>();
        for (int lo = 0; lo < 16; lo++) list.Add((byte)(0x20 | lo));
        for (int hi = 0; hi < 16; hi++) if (hi != 2) list.Add((byte)((hi << 4) | 0x2));
        list.Add(orig);
        foreach (byte v in list)
        {
            var pkt = (byte[])settingsPacket.Clone(); pkt[idx] = v;
            IntPtr buf = Marshal.AllocHGlobal(pkt.Length), ovl = Marshal.AllocHGlobal(20);
            Marshal.Copy(pkt, 0, buf, pkt.Length);
            for (int i = 0; i < 20; i += 4) Marshal.WriteInt32(ovl, i, 0);
            IntPtr ev = CreateEvent(IntPtr.Zero, true, false, null); Marshal.WriteIntPtr(ovl, 16, ev);
            bool ok = realWrite(settingsHandle, buf, (uint)pkt.Length, IntPtr.Zero, ovl);
            int err = Marshal.GetLastWin32Error();
            if (!ok && err == 997) ok = WaitForSingleObject(ev, 2000) == 0;
            Log("SWEEP value=0x" + v.ToString("X2") + " write=" + ok + (ok ? "" : " err=" + err));
            Thread.Sleep(1000);
            recFrames = 0; recTarget = (int)rate * 2; rec = new short[recTarget * nIn];
            while (recFrames < recTarget) Thread.Sleep(50);
            WriteWav(Path.Combine(logDir, "sweep_" + v.ToString("X2") + ".wav"), rec, nIn, (int)rate);
            recTarget = 0;
            Marshal.FreeHGlobal(buf); Marshal.FreeHGlobal(ovl);
        }
        Log("SWEEP done (restored 0x" + orig.ToString("X2") + ")");
    }

    // Patch the loaded DLL's import address table for the kernel32 calls it uses to talk to the HID device.
    static void HookImports(IntPtr mod)
    {
        IntPtr k32 = GetModuleHandleA("kernel32.dll");
        realWrite = (WriteFileFn)Marshal.GetDelegateForFunctionPointer(GetProcAddress(k32, "WriteFile"), typeof(WriteFileFn));
        realWriteEx = (WriteFileExFn)Marshal.GetDelegateForFunctionPointer(GetProcAddress(k32, "WriteFileEx"), typeof(WriteFileExFn));
        realReadEx = (ReadFileExFn)Marshal.GetDelegateForFunctionPointer(GetProcAddress(k32, "ReadFileEx"), typeof(ReadFileExFn));
        realCreate = (CreateFileAFn)Marshal.GetDelegateForFunctionPointer(GetProcAddress(k32, "CreateFileA"), typeof(CreateFileAFn));
        realIoctl = (DeviceIoControlFn)Marshal.GetDelegateForFunctionPointer(GetProcAddress(k32, "DeviceIoControl"), typeof(DeviceIoControlFn));
        hookWrite = (h, b, n, w, o) =>
        {
            Log("WriteFile h=" + h + " [" + n + "] " + Hex(b, n));
            if (n == 64 && Marshal.ReadByte(b) == 0x18) { settingsHandle = h; settingsPacket = new byte[n]; Marshal.Copy(b, settingsPacket, 0, (int)n); }
            return realWrite(h, b, n, w, o);
        };
        hookWriteEx = (h, b, n, o, c) => { if (n <= 64) Log("WriteFileEx h=" + h + " [" + n + "] " + Hex(b, n)); return realWriteEx(h, b, n, o, c); };
        hookReadEx = (h, b, n, o, c) => realReadEx(h, b, n, o, c);
        hookCreate = (p, a, s, sa, d, f, t) => { var r = realCreate(p, a, s, sa, d, f, t); Log("CreateFileA " + Marshal.PtrToStringAnsi(p) + " -> " + r); return r; };
        hookIoctl = (h, code, ib, inn, ob, outn, ret, o) => { if (code != 0x00224004 || ioctlLogged++ < 4) Log("DeviceIoControl h=" + h + " code=0x" + code.ToString("X8") + (inn > 0 ? " in " + Hex(ib, inn) : "")); return realIoctl(h, code, ib, inn, ob, outn, ret, o); };

        int pe = Marshal.ReadInt32(mod, 0x3C);
        int impRva = Marshal.ReadInt32(mod, pe + 0x80);
        for (int d = impRva; ; d += 20)
        {
            int nameRva = Marshal.ReadInt32(mod, d + 12); if (nameRva == 0) break;
            string dllName = Marshal.PtrToStringAnsi(new IntPtr(mod.ToInt64() + nameRva));
            int origThunk = Marshal.ReadInt32(mod, d), firstThunk = Marshal.ReadInt32(mod, d + 16);
            if (origThunk == 0) origThunk = firstThunk;
            for (int i = 0; ; i += 4)
            {
                int ent = Marshal.ReadInt32(mod, origThunk + i); if (ent == 0) break;
                if (ent < 0) continue;
                string fn = Marshal.PtrToStringAnsi(new IntPtr(mod.ToInt64() + ent + 2));
                Delegate hk = null;
                switch (fn) { case "WriteFile": hk = hookWrite; break; case "WriteFileEx": hk = hookWriteEx; break; case "CreateFileA": hk = hookCreate; break; case "DeviceIoControl": hk = hookIoctl; break; }
                if (hk == null) continue;
                IntPtr slot = new IntPtr(mod.ToInt64() + firstThunk + i); uint old;
                VirtualProtect(slot, (UIntPtr)4, 0x04, out old);
                Marshal.WriteIntPtr(slot, Marshal.GetFunctionPointerForDelegate(hk));
                VirtualProtect(slot, (UIntPtr)4, old, out old);
                Log("hooked " + dllName + "!" + fn);
            }
        }
    }
}
